/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * Drag-panes module
 *
 * (c) 2010-2017 Highsoft AS
 * Author: Kacper Madej
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/drag-panes.src.js';
